<?php
include_once 'class.task.php';
if(isset($_POST['btn-save']))
{
	$uname = $_POST['user_name'];
	$uemail = $_POST['user_email'];
	$ttask = $_POST['task_text'];
	$status = 0;
	
	$imgFile = $_FILES['task_image']['name'];
	$tmp_dir = $_FILES['task_image']['tmp_name'];
	$imgSize = $_FILES['task_image']['size'];

    if(empty($uname)){
        $errMSG = "Empty Username!!!";
    }
    else if(empty($uemail)){
        $errMSG = "Empty Useremail!!!";
    }
    else if(empty($ttask)){
        $errMSG = "Empty Task Text!!!";
    }
    else {
	
		$upload_dir = 'task_images/'; 
		$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); 
		$valid_extensions = array('jpeg', 'jpg', 'png', 'gif');

		$taskpic = rand(1000,1000000).".".$imgExt;	
		if(in_array($imgExt, $valid_extensions))
        {			
			if($imgSize < 2000000)
			{
				move_uploaded_file($tmp_dir,$upload_dir.$taskpic);
			}
			else
			{
				$errMSG = "Sorry, your file is too large.";
			}
		} 
        else
		{
			$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
		}  

	}

    if(!isset($errMSG)){
        if($task->create($uname, $uemail, $ttask, $taskpic, $status))
        {
            header("Location: add_task.php?inserted");
        }
        else
        {
            header("Location: add_task.php?failure");
        } 
    }
}
?>

<?php include_once 'header.php'; ?>
<div class="clearfix"></div>
<?php
    if(isset($errMSG)){
            ?>
            <div class="alert alert-danger">
                <span class="glyphicon glyphicon-info-sign"></span> <strong><?php echo $errMSG; ?></strong>
            </div>
            <?php
    }

    if(isset($_GET['inserted']))
    {
    	?>
        <div class="container">
    	<div class="alert alert-info">
        <strong>SUCCESS!</strong> Task was inserted successfully <a href="index.php"> HOME PAGE! </a>    
    	</div>
    	</div>
        <?php
    }
    else if(isset($_GET['failure']))
    {
?>
    <div class="container">
	<div class="alert alert-warning">
    <strong>SORRY!</strong> ERROR while inserting record !
	</div>
	</div>
    <?php
}
?>

<div class="clearfix"></div><br />

<div class="container">

 	
	 <form method='post' id="myform" enctype='multipart/form-data' >
 
    <table class='table table-bordered'>
        <tr>
            <td>User Name</td>
            <td><input type='text' name='user_name' id="user_name" value="<?php echo $uname; ?>" class='form-control'></td>
        </tr>   

        <tr>
            <td>User E-mail</td> 
            <td><input type='email' name='user_email' id="user_email" value="<?php echo $uemail; ?>" class='form-control' ></td>
        </tr>   

        <tr>
            <td>Task Text</td> 
            <td><input type='text' name='task_text' id="task_text" value="<?php echo $ttask; ?>" class='form-control' ></td>
        </tr>  

        <tr>
            <td>Task Image.</td>
            <td><input class="input-group" type="file" id="task_image"  name="task_image" accept="image/*" /></td>
        </tr>
 
        <tr>
            <td colspan="2">
            <button data-toggle="modal" data-target="#view-modal" data-id="<?php echo 'id'; ?>" id="getTask" class="btn btn-sm btn-info"><i class="glyphicon glyphicon-eye-open"></i> PreView Task</button>
            <button type="submit" class="btn btn-primary" name="btn-save">
    		<span class="glyphicon glyphicon-plus"></span> Create New Task
			</button>  
            <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; Cancel</a>
            </td>
        </tr>
 
    </table>
</form>
             <div id="view-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
             <div class="modal-dialog"> 
                  <div class="modal-content"> 
                  
                       <div class="modal-header"> 
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> 
                            <h4 class="modal-title">
                                <i class="glyphicon glyphicon-tags"></i> Task detals
                            </h4> 
                       </div> 
                       <div class="modal-body"> 
                       
                           <div id="modal-loader" style="display: none; text-align: center;">
                            <img src="ajax-loader.gif">
                           </div>
                            
                           <!-- content will be load here -->                          
                           <div id="dynamic-content"></div>

                           <div id="image-holder"></div>
                             
                        </div> 
                        <div class="modal-footer"> 
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                        </div> 
                        
                 </div> 
              </div>
       </div><!-- /.modal -->
       
</div>

<script src="assets/jquery-1.12.4.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
    
    $(document).on('click', '#getTask', function(e){        
        e.preventDefault();        

        var user_name   = $.trim($('#user_name').val());
        var user_email  = $.trim($('#user_email').val());
        var task_text   = $.trim($('#task_text').val());
        var task_image  = $.trim($('#task_image').val());

        if (user_name === '') {   
            $('#dynamic-content').html('user_name empty !!!!!!!!!!!!!');
        }
        else if (user_email === ''){
            $('#dynamic-content').html('user_email empty !!!!!!!!!!!!!!!');
        }
        else if (task_text === ''){
            $('#dynamic-content').html('task_text empty !!!!!!!!!!!!!!!');
        }
        else if (task_image === ''){
            $('#dynamic-content').html('task_image empty !!!!!!!!!!!!!!!');
        } 
        else { 
            $('#dynamic-content').html(''); // leave it blank before ajax call
            $('#modal-loader').show();     // load ajax loader        
            $.ajax({
                url: 'gettask.php',
                type: 'POST',
                data: $('#myform').serialize(),
                dataType: 'html'
            })
            .done(function(data){
                console.log(data);  
                $('#dynamic-content').html('');    
                $('#dynamic-content').html(data); // load response 
                $('#modal-loader').hide();        // hide ajax loader   
            })
            .fail(function(){
                $('#dynamic-content').html('<i class="glyphicon glyphicon-info-sign"></i> Something went wrong, Please try again...');
                $('#modal-loader').hide();
            });
        }
   });    

    $("#task_image").on('change', function() {
          //Get count of selected files
          //var countFiles = $(this)[0].files.length;
          var imgPath = $(this)[0].value;
          var extn = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();
          var image_holder = $("#image-holder");
          image_holder.empty();
          if (extn == "gif" || extn == "png" || extn == "jpg" || extn == "jpeg") {
            if (typeof(FileReader) != "undefined") {
              //loop for each file selected for uploaded.
              //for (var i = 0; i < countFiles; i++) 
              //{
                var i = 0;

                var reader = new FileReader();
                reader.onload = function(e) {
                  $("<img />", {
                    "src": e.target.result,
                    "class": "thumb-image"
                  }).appendTo(image_holder);
                }
                image_holder.show();
                reader.readAsDataURL($(this)[0].files[i]);
              //}
            } else {
              alert("This browser does not support FileReader.");
            }
          } else {
            alert("Pls select only images");
          }
        });
});
</script>   
     
</div>

<?php include_once 'footer.php'; ?>