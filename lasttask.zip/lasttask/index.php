<?php
include_once 'class.task.php';
?>
<?php include_once 'header.php'; ?>

<div class="clearfix"></div>

<div class="container">
<a href="add_task.php" class="btn btn-large btn-info"><i class="glyphicon glyphicon-plus"></i> &nbsp; Add New Task</a>
</div>

<div class="clearfix"></div><br />
<?php

        $orderBy = "id";
        $order = "desc";
        
        if(!empty($_GET["orderby"])) {
            $orderBy = $_GET["orderby"];
        }
        if(!empty($_GET["order"])) {
            $order = $_GET["order"];
        }
        
        $user_nameSort = "asc";
        $user_emailSort = "asc";
        $statusSort = "desc";
        
        if($orderBy == "user_name" and $order == "asc") {
            $user_nameSort = "desc";
        }
        if($orderBy == "user_email" and $order == "asc") {
            $user_emailSort = "desc";
        }
        if($orderBy == "status" and $order == "desc") {
            $statusSort = "asc";
        }

?>
<div class="container">
	 <table class='table table-bordered table-responsive'>
     <tr>
     <th>ID</th>
     <th><span><a href="?orderby=user_name&order=<?php echo $user_nameSort; ?>" class="column-title">User Name</a></span></th>
     <th><span><a href="?orderby=user_email&order=<?php echo $user_emailSort; ?>" class="column-title">User Emai</a></span></th>
     <th>Task Text</th>
     <th><a href="?orderby=status&order=<?php echo $statusSort; ?>" class="column-title">Status</a></span></th>
	 <th align="center">Task Image</th>
     </tr>
     <?php
		$query = "SELECT * FROM tbl_tasks ORDER BY " . $orderBy . " " . $order;       
		$records_per_page=5;
		$newquery = $task->paging($query,$records_per_page);
		$task->dataview($newquery);
	 ?>
    <tr>
        <td colspan="8" align="center">
 			<div class="pagination-wrap">
            <?php $task->paginglink($query,$records_per_page); ?>
        	</div>
        </td>
    </tr>
 
</table>
   

<?php include_once 'footer.php'; ?>