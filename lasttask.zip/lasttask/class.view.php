<?php


require_once('dbconfig.php');

class VIEW
{	

    private $db;

	public function __construct()
	{
		$database = new Database();
		$conn = $database->dbConnection();
		$this->db = $conn;
    }

    public function lastTask($sql)
	{
		$stmt = $this->db->prepare($sql);
		return $stmt;
	}
	
}
?>