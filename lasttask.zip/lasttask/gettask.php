	<?php
		if ($_SERVER['REQUEST_METHOD'] == 'POST') 
		{ ?>			
			<div class="table-responsive">		
				<table class="table table-striped table-bordered">
				    <tr>
					    <th>User Name</th>
						<td><?= $_POST['user_name']?></td>
					</tr>
					<tr>
						<th>User E-mail</th>
						<td><?= $_POST['user_email']?></td>
					</tr>
					<tr>
						<th>Task Text</th>
						<td><?= $_POST['task_text']?></td>
					</tr>
				</table>			
			</div>			
	<?php } ?> 