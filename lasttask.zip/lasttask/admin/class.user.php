<?php


require_once('../dbconfig.php');

class USER
{	

    private $db;

	public function __construct()
	{
		$database = new Database();
		$conn = $database->dbConnection();
		$this->db = $conn;
    }

    public function runQuery($sql)
	{
		$stmt = $this->db->prepare($sql);
		return $stmt;
	}
	
	
	public function doLogin($uname,$upass)
	{
		try
		{
			$stmt = $this->db->prepare("SELECT id, user_name, user_pass FROM users WHERE user_name=:uname");
			$stmt->execute(array(':uname'=>$uname));
			$userRow=$stmt->fetch(PDO::FETCH_ASSOC);
			if($stmt->rowCount() == 1)
			{
				if(password_verify($upass, $userRow['user_pass']))
				{
					$_SESSION['user_session'] = $userRow['id'];
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
	
	public function is_loggedin()
	{
		if(isset($_SESSION['user_session']))
		{
			return true;
		}
	}
	
	public function redirect($url)
	{
		header("Location: $url");
	}
	
	public function doLogout()
	{
		session_destroy();
		unset($_SESSION['user_session']);
		return true;
	}
}
?>