<?php

/**
* 
*/

class task
{
	private $db;

	public function __construct()
	{
		$database = new Database();
		$conn = $database->dbConnection();
		$this->db = $conn;
    }

	public function getID($id)
	{
		$stmt = $this->db->prepare("SELECT * FROM tbl_tasks WHERE id=:id");
		$stmt->execute(array(":id"=>$id));
		$editRow=$stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	}

	public function update($id, $uname, $uemail, $ttask, $taskpic, $status)
	{
		try {
			$stmt = $this->db->prepare("UPDATE tbl_tasks SET 
				user_name = :uname, 
				user_email = :uemail,
				task_text = :ttask, 
				task_img = :taskpic, 
				status = :status
				WHERE id = :id");

			$stmt->bindparam(":uname", $uname);
			$stmt->bindparam(":uemail", $uemail);
			$stmt->bindparam(":ttask", $ttask);
			$stmt->bindparam(":taskpic", $taskpic);
			$stmt->bindparam(":status", $status);
			$stmt->bindparam(":id", $id);
			$stmt->execute();
			return true;

		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}

	public function delete($id)
	{
		// select image from db to delete
		$stmt_select = $this->db->prepare('SELECT task_img FROM tbl_tasks WHERE id =:id');
		$stmt_select->execute(array(':id'=>$_GET['delete_id']));
		$imgRow=$stmt_select->fetch(PDO::FETCH_ASSOC);
		unlink("../task_images/".$imgRow['task_img']);
		
		// it will delete an actual record from db
		$stmt = $this->db->prepare("DELETE FROM tbl_tasks WHERE id = :id");
		$stmt->bindparam(":id",$id);
		$stmt->execute();
		return true;
	}

	public function dataview($query)
	{
		$stmt = $this->db->prepare($query);
		$stmt->execute();

		if ($stmt->rowCount()>0) {
			# code...
			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
			{ ?>
				<tr>
					<td><?php echo $row['id']; ?></td>
					<td><?php echo $row['user_name']; ?></td>
					<td><?php echo $row['user_email']; ?></td>
					<td><?php echo $row['task_text']; ?></td>
					<td><?php echo $row['status']; ?></td>
					<td><img src="../task_images/<?php echo $row['task_img']; ?>" class="img-rounded" width="120px" height="90px" /></td>
	                <td align="center">
	                <a href="edit_task.php?edit_id=<?php echo $row['id']; ?>"><i class="glyphicon glyphicon-edit"></i></a>
	                </td>
	                <td align="center">
	                <a href="delete.php?delete_id=<?php echo $row['id']; ?>"><i class="glyphicon glyphicon-remove-circle"></i></a>
	                </td>
				</tr>
			<?php	
			}
		} else {
			?> <tr><td> Empty data... </td></tr> <?php
		}
	}

	public function paging($query,$records_per_page)
	{
		$starting_position=0;
		if(isset($_GET["page_no"]))
		{
			$starting_position=($_GET["page_no"]-1)*$records_per_page;
		}
		$query2=$query." limit $starting_position,$records_per_page";
		return $query2;
	}
	
	public function paginglink($query,$records_per_page)
	{
		
		$self = $_SERVER['PHP_SELF'];
		
		$stmt = $this->db->prepare($query);
		$stmt->execute();
		
		$total_no_of_records = $stmt->rowCount();
		
		if($total_no_of_records > 0)
		{
			?><ul class="pagination"><?php
			$total_no_of_pages=ceil($total_no_of_records/$records_per_page);
			$current_page=1;
			if(isset($_GET["page_no"]))
			{
				$current_page=$_GET["page_no"];
			}
			if($current_page!=1)
			{
				$previous =$current_page-1;
				echo "<li><a href='".$self."?page_no=1'>First</a></li>";
				echo "<li><a href='".$self."?page_no=".$previous."'>Previous</a></li>";
			}
			for($i=1;$i<=$total_no_of_pages;$i++)
			{
				if($i==$current_page)
				{
					echo "<li><a href='".$self."?page_no=".$i."' style='color:red;'>".$i."</a></li>";
				}
				else
				{
					echo "<li><a href='".$self."?page_no=".$i."'>".$i."</a></li>";
				}
			}
			if($current_page!=$total_no_of_pages)
			{
				$next=$current_page+1;
				echo "<li><a href='".$self."?page_no=".$next."'>Next</a></li>";
				echo "<li><a href='".$self."?page_no=".$total_no_of_pages."'>Last</a></li>";
			}
			?></ul><?php
		}
	}
}

$task = new task($DB_con);
