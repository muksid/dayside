<?php

require_once("session.php");
    
require_once("class.user.php");

require_once('class.task.php');
  
  $auth_user = new USER();

  $del = new task();
    
  $id = $_SESSION['user_session'];
    
  $stmt = $auth_user->runQuery("SELECT * FROM users WHERE id=:id");
  $stmt->execute(array(":id"=>$id));
    
  $userRow=$stmt->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['btn-del']))
{
	$id = $_GET['delete_id'];
	$task->delete($id);
	header("Location: delete.php?deleted");	
}

?>

<?php include_once 'header.php'; ?>


<div class="container-fluid" style="margin-top:80px;">

<div class="container">

	<?php
	if(isset($_GET['deleted']))
	{
		?>
        <div class="alert alert-success">
    	<strong>Success!</strong> task was deleted... 
		</div>
        <?php
	}
	else
	{
		?>
        <div class="alert alert-danger">
    	<strong>Sure !</strong> to remove the following task ? 
		</div>
        <?php
	}
	?>	
</div>

<div class="clearfix"></div>

<div class="container">
 	
	 <?php
	 if(isset($_GET['delete_id']))
	 {
		 ?>
         <table class='table table-bordered'>
         <tr>
         <th>#</th>
         <th>User Name</th>
         <th>User E-mail</th>
         <th>Task Text</th>
         <th>status</th>
         </tr>
         <?php
         $stmt = $auth_user->runQuery("SELECT * FROM tbl_tasks WHERE id=:id");
         $stmt->execute(array(":id"=>$_GET['delete_id']));
         while($row=$stmt->fetch(PDO::FETCH_BOTH))
         {
             ?>
             <tr>
             <td><?php echo $row['id']; ?></td>
             <td><?php echo $row['user_name']; ?></td>
             <td><?php echo $row['user_email']; ?></td>
             <td><?php echo $row['task_text']; ?></td>
         	 <td><?php echo $row['status']; ?></td>
             </tr>
             <?php
         }
         ?>
         </table>
         <?php
	 }
	 ?>
</div>

<div class="container">
<p>
<?php
if(isset($_GET['delete_id']))
{
	?>
  	<form method="post">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>" />
    <button class="btn btn-large btn-primary" type="submit" name="btn-del"><i class="glyphicon glyphicon-trash"></i> &nbsp; YES</button>
    <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; NO</a>
    </form>  
	<?php
}
else
{
	?>
    <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; Back to index</a>
    <?php
}
?>
</p>
</div>	
<?php include_once 'footer.php'; ?>