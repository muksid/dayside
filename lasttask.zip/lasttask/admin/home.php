<?php

	require_once("session.php");
	
	require_once("class.user.php");

  require_once('class.task.php');

	$auth_user = new USER();
	
	
	$id = $_SESSION['user_session'];
	
	$stmt = $auth_user->runQuery("SELECT * FROM users WHERE id=:id");
	$stmt->execute(array(":id"=>$id));
	
	$userRow=$stmt->fetch(PDO::FETCH_ASSOC);

  require_once('header.php');
?>
    	
    
<div class="container-fluid" style="margin-top:80px;">
	
    <div class="container">
<table class='table table-bordered table-responsive'>
     <tr>
     <th>ID</th>
     <th>User Name</th>
     <th>User Emai</th>
     <th>Task Text</th>
     <th>Status</th>
   <th align="center">Task Image</th>
     <th colspan="2" align="center">Role</th>
     </tr>
     <?php
    $query = "SELECT * FROM tbl_tasks";       
    $records_per_page=5;
    $newquery = $task->paging($query,$records_per_page);
    $task->dataview($newquery);
   ?>
    <tr>
        <td colspan="8" align="center">
      <div class="pagination-wrap">
            <?php $task->paginglink($query,$records_per_page); ?>
          </div>
        </td>
    </tr>
 
</table>
    
    </div>

</div>

<script src="bootstrap/js/bootstrap.min.js"></script>

</body>
</html>