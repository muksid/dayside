<?php

require_once("session.php");
    
require_once("class.user.php");

require_once('class.task.php');

$auth_user = new USER();
    
    
    $id = $_SESSION['user_session'];
    
    $stmt = $auth_user->runQuery("SELECT * FROM users WHERE id=:id");
    $stmt->execute(array(":id"=>$id));
    
    $userRow=$stmt->fetch(PDO::FETCH_ASSOC);


if(isset($_GET['edit_id']))
{
    $id = $_GET['edit_id'];
    extract($task->getID($id));

}
//print_r($task_img); die();

if(isset($_POST['btn-update']))
{
    //print_r($_POST); die;
	$id = $_GET['edit_id'];

    $uname = $_POST['user_name'];
    $uemail = $_POST['user_email'];
    $ttask = $_POST['task_text'];
    $status = $_POST['status'];
    if(empty($status)){ $status = 0; }



        $imgFile = $_FILES['task_image']['name'];
        $tmp_dir = $_FILES['task_image']['tmp_name'];
        $imgSize = $_FILES['task_image']['size'];

    if($imgFile)
        {
            //print_r($id); die;
            $upload_dir = '../task_images/'; // upload directory   
            //print_r('sdasdasdasdasd'); die();
            $imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
            $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
            $taskpic = rand(1000,1000000).".".$imgExt;
            if(in_array($imgExt, $valid_extensions))
            {           
                if($imgSize < 5000000)
                {
                    unlink($upload_dir.$task_img);
                    move_uploaded_file($tmp_dir,$upload_dir.$taskpic);
                }
                else
                {
                    $errMSG = "Sorry, your file is too large it should be less then 5MB";
                }
            }
            else
            {
                $errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";        
            }   
        }
        else
        {
            //print_r('test current task'); die;
            // if no image selected the old image remain as it is.
            $taskpic = $task_img; // old image from database
            //print_r($user_name. ' task img: ' .$task_img); die;
        }    
        //print_r($taskpic); die;
        if($task->update($id, $uname, $uemail, $ttask, $taskpic, $status))
            { 
                $msg = "<div class='alert alert-info'>
                        <strong>Ok!</strong> Task was updated successfully <a href='home.php'>HOME</a>!
                        </div>";

         
                header('Refresh:1, url = home.php');
                
            }
            else
            {
                $msg = "<div class='alert alert-warning'>
                        <strong>SORRY!</strong> ERROR while updating task !
                        </div>";
            }


        	
        
}

        

?>
<?php include_once 'header.php'; ?>

<div class="container-fluid" style="margin-top:80px;">

<div class="container">
<?php
if(isset($msg))
{
	echo $msg;
}
?>
</div>

<div class="clearfix"></div><br />

<div class="container">
	 
     <form method='post' enctype='multipart/form-data'>
 
    <table class='table table-bordered'>
 
        <tr>
            <td>User Name</td>
            <td><input type='text' name='user_name' class='form-control' value="<?php echo $user_name; ?>" required></td>
        </tr>
 
        <tr>
            <td>User E-mail</td>
            <td><input type='text' name='user_email' class='form-control' value="<?php echo $user_email; ?>" required></td>
        </tr>
 
        <tr>
            <td>Task Text</td>
            <td><textarea name="task_text" class="form-control"><?php echo $task_text; ?></textarea></td>
        </tr>

        <tr>
            <td>Status</td>
            <?php if ($status == 1) {
                # code...
                $checked = 'checked';
            } else
            {
                $checked = '';                    
            } ?>
            <td><input type="checkbox" name="status" <?php echo $checked; ?> value ="1" ></td>
        </tr>

        <tr>
            <td>Task Image</td>
            <td>
                <p><img src="../task_images/<?php echo $task_img; ?>" height="150" width="150" /></p>
                <input class="input-group" type="file" name="task_image" accept="image/*" />
            </td>
        </tr>
 
        <tr>
            <td colspan="2">
                <button type="submit" class="btn btn-primary" name="btn-update">
    			<span class="glyphicon glyphicon-edit"></span>  Update this Task
				</button>
                <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; CANCEL</a>
            </td>
        </tr>
 
    </table>
</form>
     
     
</div>

<?php include_once 'footer.php'; ?>