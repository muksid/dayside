<div class="container">
	<div class="alert alert-info">
	</div>
</div>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
